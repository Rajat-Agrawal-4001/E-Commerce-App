<?php
\Cloudinary::config(array( 
  "cloud_name" => "dza7mzhl1", 
  "api_key" => "299891231945391", 
  "api_secret" => "goMsqQQwY8ZzIEzLFR9yHJRuWmA", 
  "secure" => true
));
?>